import { useState } from "react";
import { motion } from "framer-motion";

export default function App() {
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  return (
    <main className="min-h-screen bg-black text-white px-4 py-12 flex flex-col items-center justify-center space-y-12">
      <motion.h1
        className="text-5xl font-bold tracking-wide text-center"
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        VAULT OS
      </motion.h1>
      <motion.p
        className="text-xl text-center max-w-xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 1 }}
      >
        Air-Gapped Privacy Suite. Create a secure build, burn to USB, and disappear.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
      >
        <div className="bg-neutral-900 border border-neutral-800 max-w-md w-full shadow-xl p-6 space-y-4 rounded-xl">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-2 rounded bg-neutral-800 text-white border border-neutral-700"
          />
          <input
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full p-2 rounded bg-neutral-800 text-white border border-neutral-700"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-2 rounded bg-neutral-800 text-white border border-neutral-700"
          />
          <button className="w-full p-2 bg-indigo-600 hover:bg-indigo-500 rounded text-white font-semibold">
            Create Account
          </button>
        </div>
      </motion.div>
      <motion.section
        className="max-w-3xl text-left space-y-4 mt-16"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
      >
        <h2 className="text-3xl font-semibold">Setup Instructions</h2>
        <ol className="list-decimal list-inside space-y-2 text-lg">
          <li>Download the Vault OS ISO from your dashboard (coming soon).</li>
          <li>Flash to USB using <a className="underline text-indigo-400" href="https://etcher.io" target="_blank">Etcher</a> or Rufus.</li>
          <li>Reboot your computer and boot from the USB drive.</li>
          <li>Vault OS runs offline and launches with encryption and QR tools ready.</li>
        </ol>
        <p className="text-neutral-400 italic">
          For ultimate privacy, never connect the Vault OS USB to the internet.
        </p>
      </motion.section>
    </main>
  );
}